# CanoMind Build-Time Program Icon Directory (`src-tauri/icons/`)

All required desktop icons (`32x32.png`, `128x128.png`, `128x128@2x.png`, `icon.png`, `icon.ico`, `icon.icns`) are pre-generated in this folder so the project compiles immediately.

To customize the application icon before building (`npm run tauri build`):
1. Replace `icon.png` with your own 1024x1024 PNG icon.
2. Run:
   ```bash
   npx tauri icon src-tauri/icons/icon.png
   ```
