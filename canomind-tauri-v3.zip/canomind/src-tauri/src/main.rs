#![cfg_attr(not(debug_assertions), windows_subsystem = "windows")]

use serde::{Deserialize, Serialize};
use std::fs::{self, File};
use std::io::Write;
use zip::write::FileOptions;

#[derive(Serialize, Deserialize, Clone, Debug)]
pub struct MindNode {
    pub id: String,
    pub text: String,
    pub x: f64,
    pub y: f64,
    pub shape: String,
    pub color: String,
    pub progress: u8,
    pub start_week: u8,
    pub duration: u8,
}

#[derive(Serialize, Deserialize, Clone, Debug)]
pub struct MindEdge {
    pub id: String,
    pub from: String,
    pub to: String,
    pub style: String,
}

#[derive(Serialize, Deserialize, Clone, Debug)]
pub struct DiagramPage {
    pub name: String,
    pub nodes: Vec<MindNode>,
    pub edges: Vec<MindEdge>,
}

#[tauri::command]
fn export_freemind_mm(page: DiagramPage, target_path: String) -> Result<String, String> {
    let mut xml = String::from("<?xml version=\"1.0\" encoding=\"UTF-8\"?>\n<map version=\"1.0.1\">\n");
    if let Some(root) = page.nodes.first() {
        xml.push_str(&format!("  <node TEXT=\"{}\">\n", escape_xml(&root.text)));
        for child in page.nodes.iter().skip(1) {
            xml.push_str(&format!(
                "    <node TEXT=\"{}\" POSITION=\"right\"/>\n",
                escape_xml(&child.text)
            ));
        }
        xml.push_str("  </node>\n");
    }
    xml.push_str("</map>\n");
    fs::write(&target_path, xml).map_err(|e| e.to_string())?;
    Ok(format!("FreeMind (.mm) exported to {}", target_path))
}

#[tauri::command]
fn export_xmind_package(page: DiagramPage, target_path: String) -> Result<String, String> {
    let file = File::create(&target_path).map_err(|e| e.to_string())?;
    let mut zip = zip::ZipWriter::new(file);
    let options = FileOptions::default().compression_method(zip::CompressionMethod::Deflated);

    let root_title = page
        .nodes
        .first()
        .map(|n| n.text.clone())
        .unwrap_or_else(|| "Central Topic".to_string());

    let children: Vec<serde_json::Value> = page
        .nodes
        .iter()
        .skip(1)
        .map(|n| serde_json::json!({ "id": n.id, "title": n.text }))
        .collect();

    let content_json = serde_json::json!([{
        "id": page.name,
        "class": "sheet",
        "title": page.name,
        "rootTopic": {
            "id": "root",
            "title": root_title,
            "children": {
                "attached": children
            }
        }
    }]);

    zip.start_file("content.json", options).map_err(|e| e.to_string())?;
    zip.write_all(content_json.to_string().as_bytes()).map_err(|e| e.to_string())?;

    let metadata_json = serde_json::json!({
        "creator": { "name": "CanoMind", "version": "1.0.0" }
    });
    zip.start_file("metadata.json", options).map_err(|e| e.to_string())?;
    zip.write_all(metadata_json.to_string().as_bytes()).map_err(|e| e.to_string())?;

    zip.finish().map_err(|e| e.to_string())?;
    Ok(format!("XMind (.xmind) exported to {}", target_path))
}

#[tauri::command]
fn export_markdown_md(page: DiagramPage, target_path: String) -> Result<String, String> {
    let mut md = format!("# {}\n\n", page.name);
    for node in &page.nodes {
        md.push_str(&format!(
            "- **{}** (Progress: {}%, Week {}, Duration: {}w)\n",
            node.text, node.progress, node.start_week, node.duration
        ));
    }
    fs::write(&target_path, md).map_err(|e| e.to_string())?;
    Ok(format!("Markdown (.md) exported to {}", target_path))
}

fn escape_xml(input: &str) -> String {
    input
        .replace('&', "&amp;")
        .replace('<', "&lt;")
        .replace('>', "&gt;")
        .replace('"', "&quot;")
}

fn main() {
    tauri::Builder::default()
        .invoke_handler(tauri::generate_handler![
            export_freemind_mm,
            export_xmind_package,
            export_markdown_md
        ])
        .run(tauri::generate_context!())
        .expect("error while running CanoMind Tauri application");
}
