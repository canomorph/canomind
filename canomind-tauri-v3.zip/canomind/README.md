# CanoMind — Masaüstü Diyagram, Zihin Haritası ve Planlama Stüdyosu (Tauri + Rust)

Bu proje, **CanoMind Program Tanım Dokümanı**'na birebir uygun olarak geliştirilmiş, **Tauri v2 (Rust backend + Web frontend)** tabanlı, Windows, macOS ve Linux üzerinde doğrudan derlenebilir masaüstü uygulamasıdır.

---

## 1. Özellik Özeti

- **Microsoft Office Başlangıç (Backstage) Ekranı:** Uygulama açıldığında önceden açık dosya gelmez; yeni boş dosya oluşturma, şablon seçme (`XMind Radial Mindmap`, `Visio System Flowchart`, `Gantt Project Schedule`, `MindManager Org Tree`) veya önceki çalışılan dosyaları açma ekranı karşılar.
- **Üst Bar Sıralaması:** `CanoMind` program adı → açık dosya sekmeleri → arama çubuğu → hızlı tema geçişi ve ayarlar (`Settings`) butonu.
- **Duyarlı Office Fluent Ribbon:** `File | Home | Insert | Draw | Design | Data | Process | Review | View | Help` sekmeleri ve en sağda `Comments` butonu. Sekme başlıklarına **çift tıklandığında** veya pencere daraldığında kompakt açılır pencere (popover) moduna geçer.
- **XMind + Visio + Gantt Çalışma Alanı:** Seçili düğümlerin kenarlarındaki `+` butonlarıyla bağlı alt dal oluşturma, sürükle-bırak, serbest çizim ve Gantt zaman çizelgesi.
- **Tasarım (Design) Özelleştirmeleri:** Izgarasız saf beyaz (açık mod) veya nötr koyu gri (koyu mod) çalışma alanı, özel arkaplan rengi seçimi ve ölçüsü 8 yönden özgürce değiştirilebilen `PNG / JPG` arkaplan görseli ekleme.
- **Mevcut Çalışmayı Koruyan Şablon Sistemi:** Açık bir dosyada farklı bir şablon seçildiğinde mevcut çalışma silinmez; aynı dosya içinde yeni bir sayfa olarak eklenir.
- **Çoklu Dil Desteği:** Ayarlardan değiştirilebilen **Türkçe (`tr-TR`)**, **İngilizce (`en-US`)** ve **Çince (`zh-CN`)** arayüz dili + Çince dahil yazım denetimi dili seçimi.
- **İçe / Dışa Aktarma:** `.xmind` ve `.mm` (FreeMind) içe aktarma; `.xmind`, `.mm`, `.md`, `PDF`, `PNG`, `JPG` dışa aktarma.

---

## 2. Kurulum ve Derleme Adımları (Windows / macOS / Linux)

### Ön Gereksinimler
1. **Rust Araç Zinciri:** [rustup.rs](https://rustup.rs/) üzerinden Rust (`rustc` ve `cargo`) kurulu olmalıdır.
2. **Node.js (v18+):** Tauri CLI komutlarını çalıştırmak için `npm` kurulu olmalıdır.

### Adım 1: Bağımlılıkları Yükleyin
Proje klasöründe terminal açıp aşağıdaki komutu çalıştırın:
```bash
npm install
```

### Adım 2: Geliştirme Modunda Çalıştırın
Uygulamayı masaüstü penceresinde canlı olarak başlatmak için:
```bash
npm run dev
```
*(Alternatif olarak doğrudan Rust üzerinden `cd src-tauri && cargo run` komutunu da kullanabilirsiniz.)*

### Adım 3: Kurulum Paketi (Installer / Binary) Derleyin
İşletim sisteminize uygun kurulum dosyasını (`.msi` / `.exe`, `.dmg` / `.app`, `.deb` / `.AppImage`) üretmek için:
```bash
npm run build
```

### Derleme Öncesi Program Simgesini Değiştirme
Uygulama simgesini derlemeden önce değiştirmek isterseniz `src-tauri/icons/icon.png` dosyasını kendi logonuzla değiştirip şu komutu çalıştırmanız yeterlidir:
```bash
npx tauri icon src-tauri/icons/icon.png
```
